package com.example.Pyramidions.Models;

public class Employee {
    private String empName;
    private String empId;
    private double empSalary;
    private int empAge;
    private String empImage;

    public Employee(String empName, String empId, double empSalary, int empAge, String empImage) {
        this.empName = empName;
        this.empId = empId;
        this.empSalary = empSalary;
        this.empAge = empAge;
        this.empImage = empImage;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public void setEmpSalary(double empSalary) {
        this.empSalary = empSalary;
    }

    public void setEmpAge(int empAge) {
        this.empAge = empAge;
    }

    public void setEmpImage(String empImage) {
        this.empImage = empImage;
    }

    public String getEmpName() {
        return empName;
    }

    public String getEmpId() {
        return empId;
    }

    public double getEmpSalary() {
        return empSalary;
    }

    public int getEmpAge() {
        return empAge;
    }

    public String getEmpImage() {
        return empImage;
    }
}
